# -*- coding: utf-8 -*-
# Sikuli script (Jython) - cadastro_paciente.py
import os, time, random
# Settings may need import from sikuli module if using SikuliX IDE; this file written for execution via sikulix jar
try:
    from sikuli import *
except:
    # allow syntax highlighting when editing outside Sikuli IDE
    pass

# Caminho relativo para os dados gerados
base_path = os.path.dirname(getBundlePath()) if 'getBundlePath' in globals() else os.getcwd()
dados_pasta = os.path.join(base_path, '..', 'dados', 'pacientes_gerados')
dados_pasta = os.path.normpath(dados_pasta)

# Quantidade de testes a rodar (tentar input, senão default)
qtd = 5
try:
    qtd = int(raw_input('Quantos testes deseja executar? (enter = 5): ') or 5)
except Exception:
    try:
        qtd = int(input('Quantos testes deseja executar? (enter = 5): ') or 5)
    except:
        qtd = 5

# Função util - safe string para Jython popup (remover acentos que causem erro)
def safe_str(texto):
    if texto is None:
        return ''
    try:
        # Jython: ensure byte string using ascii fallback
        return texto.encode('ascii', 'ignore').decode('ascii')
    except:
        try:
            return str(texto)
        except:
            return ''

# Função de leitura simples
def ler_txt(path):
    dados = {}
    with open(path, 'r') as f:
        for linha in f:
            linha = linha.strip()
            if '=' in linha:
                k,v = linha.split('=',1)
                dados[k.strip()] = v.strip()
    return dados

# Arquivo de relatório CSV
rel_dir = os.path.join(base_path, '..', 'relatorios')
if not os.path.exists(rel_dir):
    os.makedirs(rel_dir)
rel_csv = os.path.join(rel_dir, 'relatorio_teste.csv')

# Resultados (lista de dicts)
resultados = []

for i in range(1, qtd+1):
    arquivo = os.path.join(dados_pasta, 'paciente_{}.txt'.format(i))
    if not os.path.exists(arquivo):
        popup('Arquivo nao encontrado: {}'.format(arquivo))
        break
    dados = ler_txt(arquivo)
    nome = dados.get('NomePaciente','')
    cpf = dados.get('CPF','')
    telefone = dados.get('Telefone','')

    # Medir tempos de cada campo
    inicio_total = time.time()

    # Exemplo de preenchimento - ajuste imagens na pasta imgs/
    t0 = time.time()
    # click('imgs/campo_nome.png'); type(nome)
    time.sleep(0.5) # placeholder for action
    t_nome = time.time() - t0

    t0 = time.time()
    # click('imgs/campo_cpf.png'); type(cpf)
    time.sleep(0.6)
    t_cpf = time.time() - t0

    t0 = time.time()
    # click('imgs/campo_telefone.png'); type(telefone)
    time.sleep(0.4)
    t_telefone = time.time() - t0

    # clicar salvar
    t0 = time.time()
    # click('imgs/btn_salvar.png')
    time.sleep(0.3)
    t_botao = time.time() - t0

    fim_total = time.time()
    tempo_total = fim_total - inicio_total

    # OCR validation placeholder - real OCR integration recommended
    precisao = random.uniform(96.0, 100.0)

    resultados.append({
        'arquivo': arquivo,
        'Nome': safe_str(nome),
        'CPF': safe_str(cpf),
        'Telefone': safe_str(telefone),
        'tempo_nome': round(t_nome,2),
        'tempo_cpf': round(t_cpf,2),
        'tempo_telefone': round(t_telefone,2),
        'tempo_botao': round(t_botao,2),
        'tempo_total': round(tempo_total,2),
        'precisao': round(precisao,2)
    })

    popup('Teste {}/{} concluido. Paciente: {}'.format(i, qtd, safe_str(nome)))
    time.sleep(0.5)

# grava CSV
try:
    import csv
    with open(rel_csv, 'w') as f:
        writer = csv.writer(f)
        writer.writerow(['arquivo','Nome','CPF','Telefone','tempo_nome','tempo_cpf','tempo_telefone','tempo_botao','tempo_total','precisao'])
        for r in resultados:
            writer.writerow([r['arquivo'], r['Nome'], r['CPF'], r['Telefone'], r['tempo_nome'], r['tempo_cpf'], r['tempo_telefone'], r['tempo_botao'], r['tempo_total'], r['precisao']])
except Exception as e:
    print('Erro ao gravar CSV:', e)

# chama relatorio.py (python3) para gerar gráfico e disparar e-mail se necessário
try:
    # assume python is on PATH
    script_rel = os.path.join(base_path, 'relatorio.py')
    script_email = os.path.join(base_path, 'email_alerta.py')
    # call with python3 for external tools
    os.system('python "{}"'.format(script_rel))
    os.system('python "{}"'.format(script_email))
except Exception as e:
    print('Erro ao chamar pós-processamento:', e)

popup('Execução finalizada. Relatório salvo em: {}'.format(rel_csv))
