# -*- coding: utf-8 -*-
import os, csv
base = os.path.dirname(os.path.abspath(__file__))
rel_csv = os.path.join(base, 'relatorios', 'relatorio_teste.csv')

# CONFIGURE estes valores antes de usar
SMTP_SERVER = 'smtp.example.com'
SMTP_PORT = 587
SMTP_USER = 'seu_email@example.com'
SMTP_PASS = 'SUA_SENHA_OU_APP_PASSWORD'
EMAIL_TO = 'qa@example.com'

# Lê CSV e verifica precisão média
if not os.path.exists(rel_csv):
    print('Relatório não encontrado, não será enviado email.')
else:
    precisao_media = 0.0
    count = 0
    with open(rel_csv, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        total = 0.0
        rows = 0
        for r in reader:
            try:
                total += float(r.get('precisao',0))
                rows += 1
            except:
                pass
        if rows > 0:
            precisao_media = total / rows

    print('Precisão média calculada:', precisao_media)
    if precisao_media < 98.0:
        print('A precisão está abaixo de 98% — enviar alerta (configurar SMTP).')
        # envio de email - implementar conforme ambiente
    else:
        print('Precisão OK — sem envio de email.')
