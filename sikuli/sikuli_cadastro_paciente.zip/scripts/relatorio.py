# -*- coding: utf-8 -*-
import os, pandas as pd, matplotlib.pyplot as plt
base = os.path.dirname(os.path.abspath(__file__))
rel_csv = os.path.join(base, 'relatorios', 'relatorio_teste.csv')
grafico = os.path.join(base, 'relatorios', 'grafico_resultados.png')

if not os.path.exists(rel_csv):
    print('Arquivo de relatório não encontrado:', rel_csv)
else:
    df = pd.read_csv(rel_csv)
    # seleciona colunas de tempo (soma por linha ou por campo)
    campos = ['tempo_nome','tempo_cpf','tempo_telefone','tempo_botao']
    # calcula média por campo
    medias = [df[c].mean() for c in campos]
    labels = ['Nome','CPF','Telefone','Botão']

    plt.figure(figsize=(8,4))
    plt.barh(labels, medias)
    plt.xlabel('Tempo médio (s)')
    plt.title('Tempo médio de preenchimento por campo')
    plt.tight_layout()
    if not os.path.exists(os.path.join(base, 'relatorios')):
        os.makedirs(os.path.join(base, 'relatorios'))
    plt.savefig(grafico)
    print('Gráfico salvo em', grafico)
