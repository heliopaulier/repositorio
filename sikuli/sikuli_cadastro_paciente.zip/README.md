Projeto SikuliX + VSCode: Cadastro de Paciente (package)
======================================================

Estrutura do projeto:
- scripts/cadastro_paciente.sikuli/cadastro_paciente.py  -> script principal (Sikuli, Jython)
- scripts/relatorio.py                                   -> gera gráfico de tempo (Python3)
- scripts/email_alerta.py                                -> envia e-mail (configurar depois)
- gerarTxt.py                                            -> gera os arquivos paciente_1.txt ...
- dados/pacientes_gerados/                               -> pasta onde os .txt serão gerados
- relatorios/                                            -> saída: CSV e imagem do gráfico
- .vscode/tasks.json                                     -> task para rodar SikuliX via VS Code

Instruções rápidas:
1) Coloque seu sikulix jar em: C:\Sikulix\sikulixide-2.0.5.jar (conforme configurado)
2) Abra o projeto no VS Code (esta pasta).
3) Gere arquivos de teste: execute em terminal: python gerarTxt.py
4) No VS Code, abra Command Palette -> Run Task -> Executar SikuliX - Cadastro Paciente
   (ou Ctrl+Shift+B se preferir configurar atalho)
5) Ajuste imagens na pasta scripts/cadastro_paciente.sikuli/imgs (substitua os PNGs por capturas reais)
6) Configure o email em scripts/email_alerta.py quando desejar ativar o envio.

Observações:
- O script Sikuli (cadastro_paciente.py) foi escrito para ser compatível com Jython (Python 2.7).
  Evite f-strings e recursos do Python 3 dentro desse arquivo.
- Os utilitários relatorio.py e email_alerta.py rodam com Python 3 e usam bibliotecas Python (pandas, matplotlib).
- Para OCR avançado via Tesseract, instale Tesseract no sistema e ajuste pytesseract.tesseract_cmd em relatorio.py ou helpers.
