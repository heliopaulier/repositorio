# -*- coding: utf-8 -*-
import os, random
from faker import Faker
fake = Faker('pt_BR')

base = os.path.dirname(os.path.abspath(__file__))
pasta = os.path.join(base, "dados", "pacientes_gerados")
if not os.path.exists(pasta):
    os.makedirs(pasta)

qtd = 5
try:
    qtd_input = raw_input if 'raw_input' in globals() else input
    v = int(qtd_input("Quantos arquivos deseja gerar? (enter = 5): ") or 5)
    qtd = v
except Exception:
    pass

def gerar_cpf():
    # Gera CPF simples (não necessariamente validado contra base de CPF reais)
    def calc_digito(digs):
        soma = sum(int(d)*w for d,w in zip(digs, range(len(digs)+1,1,-1)))
        resto = 11 - soma % 11
        return '0' if resto > 9 else str(resto)
    numeros = [str(random.randint(0,9)) for _ in range(9)]
    numeros.append(calc_digito(numeros))
    numeros.append(calc_digito(numeros))
    return ''.join(numeros)

for i in range(1, qtd+1):
    paciente = {
        "NomePaciente": fake.name(),
        "NomeMae": fake.name_female(),
        "NomePai": fake.name_male(),
        "Telefone": fake.phone_number(),
        "CPF": gerar_cpf(),
        "RG": str(random.randint(1000000,9999999))
    }
    nome = os.path.join(pasta, "paciente_{}.txt".format(i))
    with open(nome, "w", encoding="utf-8") as f:
        for k,v in paciente.items():
            f.write("{}={}\n".format(k,v))
    print("Gerado:", nome)
print("Arquivos criados em:", pasta)
