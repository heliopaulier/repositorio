# report/generate_report.py
import json
import sys
from pathlib import Path

INPUT = sys.argv[1] if len(sys.argv)>1 else 'reports/metrics.json'
OUTPUT = sys.argv[2] if len(sys.argv)>2 else 'reports/summary.html'

lines = Path(INPUT).read_text().strip().splitlines() if Path(INPUT).exists() else []
records = [json.loads(l) for l in lines]

total = len(records)
passed = sum(1 for r in records if r.get('status')==1)
failed = total - passed
avg_time = sum(r.get('duration',0) for r in records)/total if total>0 else 0

html = f"""<html><head><meta charset='utf-8'><title>Relatório Executivo</title></head><body>
<h1>Resumo</h1><p>Total: {total}</p><p>Sucesso: {passed}</p><p>Falha: {failed}</p><p>Tempo médio: {avg_time:.2f}s</p>
</body></html>"""

Path(OUTPUT).parent.mkdir(parents=True, exist_ok=True)
Path(OUTPUT).write_text(html, encoding='utf-8')
print('Gerado', OUTPUT)
