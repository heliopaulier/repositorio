# Teste de Cadastro de Paciente (Refatorado)

Este projeto automatiza o cadastro e edição de pacientes em Oracle Forms usando SikuliX + IA + PyAutoGUI e integra com PyTest e Allure.

## Como preparar
1. Instale Python 3.10+, Java 11+, Tesseract OCR.
2. Ajuste caminhos no arquivo engine/sikuli_wrapper.py para o seu sikulix.jar.
3. Instale dependências: `pip install -r requirements.txt`.
4. Adicione templates (imagens) na pasta `sikuli/PAC020-CAD-PAC.sikuli/templates/` com os nomes referenciados.
