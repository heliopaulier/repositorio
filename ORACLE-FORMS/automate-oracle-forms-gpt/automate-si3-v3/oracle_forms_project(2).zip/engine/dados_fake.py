from faker import Faker
import json
from pathlib import Path
fake = Faker('pt_BR')
def gerar_paciente_dict():
    p = {
        'NomePaciente': fake.name(),
        'NomeMae': fake.name_female(),
        'NomePai': fake.name_male(),
        'Telefone': fake.phone_number(),
        'CPF': fake.cpf(),
        'RG': str(fake.random_number(digits=7, fix_len=True)),
        'DataNascimento': fake.date_of_birth(minimum_age=18, maximum_age=80).strftime('%d%m%Y'),
        'CEP': fake.postcode(),
        'Email': fake.ascii_email(),
        'Hora': '1900',
        'Sexo': 'FEMININO',
        'Nacionalidade': 'BRASILEIRA'
    }
    return p
def salvar_json(paciente: dict, caminho: str):
    Path(caminho).parent.mkdir(parents=True, exist_ok=True)
    with open(caminho, 'w', encoding='utf-8') as f:
        json.dump(paciente, f, ensure_ascii=False, indent=2)
if __name__ == '__main__':
    p = gerar_paciente_dict()
    salvar_json(p, 'sikuli/PAC020-CAD-PAC.sikuli/gerar-nomes/paciente_1.json')
    print('Gerado:', p)
