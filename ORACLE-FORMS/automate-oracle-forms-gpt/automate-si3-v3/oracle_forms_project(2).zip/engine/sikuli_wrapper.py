import subprocess, os
SIKULI_JAR = '/path/to/sikulix.jar'  # ajuste
def executar_sikuli(sikuli_script_path: str, timeout: int = 600):
    sikuli_script_path = os.path.abspath(sikuli_script_path)
    cmd = ['java', '-jar', SIKULI_JAR, '-r', sikuli_script_path]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return proc.returncode, proc.stdout, proc.stderr
    except subprocess.TimeoutExpired:
        return -1, '', 'TIMEOUT'
if __name__ == '__main__':
    rc, out, err = executar_sikuli('sikuli/PAC020-CAD-PAC.sikuli')
    print(rc, out, err)
